/*Given an integer array find the first repeating element from it and print it.
 * Example Input:arr[] = { 1, 2, 3, 10, 2, 4, 5, 7, 8 }Example
 *  Output:First Repeated Element is:2Example Input:arr[] = { 1, 2, 3, 10, 6, 4, 3, 7, 10}
 *  Example Output:First Repeated Element is:3
 */
package core_java;

import java.util.HashSet;
import java.util.Scanner;

public class ps12 {
	  static void printFirstRepeating(int arr[])
		    {
		        int min = -1;
		 
		        HashSet<Integer> set = new HashSet<>();
		        for (int i=arr.length-1; i>=0; i--)
		        {
		            if (set.contains(arr[i]))
		                min = i;
		            else 
		                set.add(arr[i]);
		        }
		        if (min != -1)
		          System.out.println("The first repeating element is " + arr[min]);
		        else
		          System.out.println("There are no repeating elements");
		    }
		    public static void main (String[] args) throws java.lang.Exception
		    {
		    	 Scanner sc = new Scanner(System.in);
		    	 System.out.println("enter length of array : ");
		    	int[] arr = new int[sc.nextInt()];
		        System.out.println("enter array values : ");
		        for (int i = 0; i < arr.length; i++) {
		            arr[i] = sc.nextInt();
		         }
		        printFirstRepeating(arr);
		    }
		}
