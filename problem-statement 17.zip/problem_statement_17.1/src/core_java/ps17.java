/*Given an expression string exp , 
 * write a program to examine whether the pairs and the orders of �{�,�}�,�(�,�)�,�[�,�]� are correct in an expression.
 *  Check for balanced parentheses in an expression.
 *   Input Format:Any String containing combination of parenthesis from below set,Set :
 *    [ �(�, �)�, �[�, �]�, �{�, �}� ]Output Format:Output String as �Balanced� or 
 *    �Not Balanced�Illustration with Example:Input: exp = �[()]{}{[()()]()}�Output:BalancedInput:
 *    exp = �[(])}�Output:Not Balanced
 */
package core_java;


import java.util.*;
public class ps17 {
	// function to check if brackets are balanced
		static boolean areBracketsBalanced(String expr)
		{
			// Using ArrayDeque is faster than using Stack class
			Deque<Character> stack
				= new ArrayDeque<Character>();

			// Traversing the Expression
			for (int i = 0; i < expr.length(); i++)
			{
				char x = expr.charAt(i);

				if (x == '(' || x == '[' || x == '{')
				{
					// Push the element in the stack
					stack.push(x);
					continue;
				}

				// If current character is not opening
				// bracket, then it must be closing. So stack
				// cannot be empty at this point.
				if (stack.isEmpty())
					return false;
				char check;
				switch (x) {
				case ')':
					check = stack.pop();
					if (check == '{' || check == '[')
						return false;
					break;

				case '}':
					check = stack.pop();
					if (check == '(' || check == '[')
						return false;
					break;

				case ']':
					check = stack.pop();
					if (check == '(' || check == '{')
						return false;
					break;
				}
			}

			// Check Empty Stack
			return (stack.isEmpty());
		}

		// Driver code
		public static void main(String[] args)
		{
			String expr = "([{}])";

			// Function call
			if (areBracketsBalanced(expr))
				System.out.println("Balanced ");
			else
				System.out.println("Not Balanced ");
		}
	}


