/*You are climbing a staircase.
 *  It takes n steps to reach the top.
 *  Each time you can either climb 1 or 2 steps. 
 *  In how many distinct ways can you climb to the top?
 *  Example 1:Input: n = 2Output: 2Explanation: There are two ways to climb to the top.1.
 *   1 step + 1 step2. 2 stepsExample 2:Input: n = 3
 *   Output: 3Explanation: There are three ways to climb to the top.1. 1 step + 1 step + 1 step2. 1 step + 2 steps3. 2 steps + 1 stepConstraints:1 <= n <= 45
 */
package core_java;
public class ClimbingStairs {
	 static int fib(int n)
	    {
	        if (n <= 1)
	            return n;
	        return fib(n - 1) + fib(n - 2);
	    }
	 
	    // Returns number of ways to reach s'th stair
	    static int countWays(int s)
	    {
	        return fib(s + 1);
	    }
	 
	    /* Driver program to test above function */
	    public static void main(String args[])
	    {
	        int s = 1;
	        System.out.println("Number of ways = " + countWays(s));

	        int s1 = 3;
	        System.out.println("Number of ways = " + countWays(s1));

	      
	        
	    }
	}


