/*Given a value V, we want to make changes for V rupees.
 *  We have infinite supply of eachof the denominations in Indian currency.i.e.,
 *   we have infinite supply of {1,2,5,10,20,50,100,500,2000} valued coins/notes.
 *   Which is the minimum number of coins and/or notes needed to make the changes for V Rs.
 *   Example Input:70Example Output:2.   Break Down -Rs.50 * 1 + Rs.20 * 1Example Input:121Example Output:3
 *   .Break Down -Rs.100 * 1 + Rs.20 * 1 + Rs 1 * 1Example Input:2045 Example Output:3.  
 *    Break Down -Rs.2000 * 1 + Rs20 * 2 + 5Rs. * 1
 */

package core_java;


import java.util.Vector;

public class coin_problem
{
  
    static int deno[] = {1,2,5,10,20,50,100,500,2000};
    static int n = deno.length;

    static void findMin(int V)
    {
    	int count=0;
        Vector<Integer> ans = new Vector<>();
  
        for (int i = n - 1; i >= 0; i--)
        {
            while (V >= deno[i]) 
            {
                V -= deno[i];
                ans.add(deno[i]);
                count++;

            }
        }
        System.out.print(count+". Break Down-");
        for (int i = 0; i < ans.size(); i++)
        {
            System.out.print(
                " Rs." + ans.elementAt(i)+"*1");
            if(i<1) {
            	System.out.print(" +");
            }
        }
    }
  
    public static void main(String[] args) 
    {
        int n = 70;
        findMin(n);
    }
}